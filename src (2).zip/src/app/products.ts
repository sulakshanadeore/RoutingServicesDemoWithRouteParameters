export class Products {
    Prodid:number;
    ProductName:string;
    
    constructor(productid:number,name:string,price:number)
    {
    this.Prodid=productid;
    this.ProductName=name;
    
    }

}
